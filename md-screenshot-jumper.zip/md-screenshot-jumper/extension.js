const vscode = require("vscode");

let enabled = true;
let watcher;

function activate(context) {
  // Status bar toggle
  const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
  statusBar.text = "🖼️ Screenshot Jumper: ON";
  statusBar.command = "mdScreenshotJumper.toggle";
  statusBar.show();

  const toggleCommand = vscode.commands.registerCommand("mdScreenshotJumper.toggle", () => {
    enabled = !enabled;
    statusBar.text = `🖼️ Screenshot Jumper: ${enabled ? "ON" : "OFF"}`;
    vscode.window.showInformationMessage(`Screenshot Jumper ${enabled ? "enabled" : "disabled"}`);
  });

  // Watch markdown files
  watcher = vscode.workspace.createFileSystemWatcher("**/*.md");

  watcher.onDidChange(async (uri) => {
    try {
      if (!enabled) return;

      // Check if this file is already open in an editor
      const openEditor = vscode.window.visibleTextEditors.find(
        (ed) => ed.document.uri.fsPath === uri.fsPath
      );
      if (!openEditor) {
        return; // Skip if file not open
      }

      // Try to ensure document is up-to-date: reopen the document
      const doc = openEditor.document;
      // If the document is dirty (has unsaved changes in editor), skip acting
      if (doc.isDirty) {
        return;
      }

      // Reload document by opening it (this makes sure content is fresh)
      const freshDoc = await vscode.workspace.openTextDocument(doc.uri);
      // If the editor's document differs, show the fresh one
      const editor = await vscode.window.showTextDocument(freshDoc, { preview: false, viewColumn: openEditor.viewColumn });

      const text = freshDoc.getText();
      const regex = /!\[Screenshot\]\([^)]+\)/g;

      let match, lastMatch;
      while ((match = regex.exec(text)) !== null) {
        lastMatch = match;
      }

      if (lastMatch) {
        const pos = freshDoc.positionAt(lastMatch.index);

        // Move cursor
        editor.selection = new vscode.Selection(pos, pos);

        // Scroll so it's centered
        editor.revealRange(
          new vscode.Range(pos, pos),
          vscode.TextEditorRevealType.InCenter
        );

        // Optional: briefly flash the line by selecting it then deselecting after 500ms
        const line = freshDoc.lineAt(pos.line);
        editor.selection = new vscode.Selection(line.range.start, line.range.end);
        setTimeout(() => {
          editor.selection = new vscode.Selection(pos, pos);
        }, 500);
      }
    } catch (err) {
      console.error("md-screenshot-jumper error:", err);
    }
  });

  context.subscriptions.push(toggleCommand, watcher, statusBar);
}

function deactivate() {
  if (watcher) {
    watcher.dispose();
  }
}

module.exports = { activate, deactivate };